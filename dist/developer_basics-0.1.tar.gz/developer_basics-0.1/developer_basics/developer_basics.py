import math

class basic_class:
    def sqrt(x):
        return math.sqrt(x)